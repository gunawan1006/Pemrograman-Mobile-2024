import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

// =========================
// ROOT APP
// =========================
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kuliner Sulbar',
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}

// =========================
// MODEL DATA
// =========================
class Kuliner {
  String nama;
  String gambar;
  String deskripsi;

  Kuliner({
    required this.nama,
    required this.gambar,
    required this.deskripsi,
  });
}

// =========================
// HOME PAGE (LIST VIEW)
// =========================
class HomePage extends StatelessWidget {

  final List<Kuliner> dataKuliner = [
    Kuliner(
      nama: "Jepa",
      gambar: "assets/jepa.jpg",
      deskripsi: "Jepa merupakan makanan tradisional khas Mandar yang berbahan dasar singkong dan parutan kelapa. Berbentuk lingkaran dengan aroma khas singkong bakar. Biasanya, makanan ini disajikan dengan ikan teri, ikan tuing-tuing, atau cumiy",
    ),
    Kuliner(
      nama: "Bau Peapi",
      gambar: "assets/Bau_Peapi.jpg",
      deskripsi: "Bau Peapi merupakan salah satu kuliner tradisional khas masyarakat Mandar di Sulawesi Barat yang hingga kini masih lestari dan digemari. Hidangan ikan berkuah pedas ini dikenal dengan cita rasa asam, gurih, dan aroma rempah yang kuat, mencerminkan kekayaan kuliner pesisir Mandar yang dekat dengan hasil laut.",
    ),
    Kuliner(
      nama: "Golla Kambu",
      gambar: "assets/golla_kambu.jpeg",
      deskripsi: "Golla kambu adalah salah satu kuliner khas dari Kabupaten Polewali Mandar, Sulawesi Barat, yang sangat digemari masyarakat. Makanan ini mirip wajik dengan cita rasa manis khas yang terbuat dari tiga bahan utama: beras ketan, kelapa muda parut, dan kacang tanah sangrai, yang dipadukan dengan gula merah.",
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Kuliner Sulawesi Barat"),
        backgroundColor: Colors.red,
      ),

      body: ListView.builder(
        itemCount: dataKuliner.length,
        itemBuilder: (context, index) {
          final item = dataKuliner[index];

          return Card(
            margin: EdgeInsets.all(10),
            child: ListTile(
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.asset(
                  item.gambar,
                  width: 60,
                  height: 60,
                  fit: BoxFit.cover,
                ),
              ),

              title: Text(item.nama),
              subtitle: Text(item.deskripsi),
              
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => DetailPage(data: item),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}

// =========================
// DETAIL PAGE
// =========================
class DetailPage extends StatelessWidget {
  final Kuliner data;

  DetailPage({required this.data});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(data.nama),
        backgroundColor: Colors.red,
      ),

      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            // GAMBAR
            Image.asset(
              data.gambar,
              width: double.infinity,
              height: 250,
              fit: BoxFit.cover,
            ),

            SizedBox(height: 15),

            // JUDUL
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                data.nama,
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),

            SizedBox(height: 10),

            // DESKRIPSI
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                data.deskripsi,
                textAlign: TextAlign.justify,
                style: TextStyle(fontSize: 16),
              ),
            ),

            SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}